#import
from tkinter import *
from tkinter.messagebox import *
from pytube import YouTube
import re

#DisplayWindow
window=Tk()
window.geometry('500x300')
window.title('YouTube Downloader')
window.resizable(0,0)

#download video
def Downloader():
    videourl=str(link.get())
    checkValid=re.match(r'^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+',videourl)
    if checkValid:
        url = YouTube(str(link.get()))
        video=url.streams.first()
        video.download()
        text='Video has been Downloaded'
    else:
        text="Please insert valid url"
    showinfo(title='Message', message=text)

#Window Caption
Label(window,text='YouTube Downloader', font='Helvetica 25 bold').pack()
#URL field
link=StringVar()
Label(window,text='URL:' ,font='Helvetica 15 bold').place(x=5,y=85)
link_enter=Entry(window,width=70,textvariable=link).place(x=60,y=90)
#Button
Button(window,text='Download',font='Helvetica 15 bold',command=Downloader).place(x=180,y=150)

global text
text=''
window.mainloop()


